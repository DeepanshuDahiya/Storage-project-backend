import express from "express";
import { getPlans } from "../Controllers/userPlans.controller";

const router = express.Router();

router.get("/", getPlans);

export default router;
