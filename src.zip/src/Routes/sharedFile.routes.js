import express from "express";
import { requireAuth } from "../Middlewares/auth.middleware.js";
import {
  accessSharedFile,
  createShareLink,
  deleteSharedLink,
  getAllSharedLinksByUser,
  modifyShareLink,
} from "../Controllers/sharedFile.controller.js";

const router = express.Router();

router.post("/:fileId", requireAuth, createShareLink);

router.patch("/:sharedLinkId", requireAuth, modifyShareLink);

router.delete("/:sharedLinkId", requireAuth, deleteSharedLink);

router.get("/:token", accessSharedFile);

router.get("/all", getAllSharedLinksByUser);

export default router;
